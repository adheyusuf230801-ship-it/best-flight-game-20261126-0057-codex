# AGENTS.md

Your operating manual for this workspace, written by you. Your main instructions cover how you work in general. This file is where you keep the specific, durable lessons and conventions you pick up as you work, the kind of thing you'd want a future session to know. It's not about the user (that goes in `USER.md` and your memory) or your personality (that's `SOUL.md`); it's about how you get work done here.

## Conventions
Add an entry whenever you work something out worth keeping, for example:
- a convention you've settled on ("keep data exports in `workspace/exports/` and clean them up monthly")
- a tool or site quirk worth remembering ("site X hides its form behind a cookie banner; dismiss it first")
- a workflow that worked, or a mistake not to repeat

It starts empty and is meant to grow slowly. Don't pad it; a short, accurate file beats a long, stale one.

## Free-mint checks — speed lessons (Andee complained checks were slow, 2026-11-06)
- Free pools vanish in minutes; a check should target minutes, not tens of minutes. Andee explicitly asked Rio not to be slow.
- Do NOT guess ABIs first. The fastest reliable route: fetch the site's JS bundle, grep the real contract addresses AND the ABI signature strings (e.g. `"function quoteMint(uint256,address)..."`), then probe exactly those. Guessing view names (price(), costFor(), ...) wastes many slow RPC round-trips — the FORGE check (2026-11-06) lost most of its time this way, plus the site's displayed "Token" address was only an EIP-1167 proxy while the mint contract was a different address in the bundle config.
- Public BSC RPCs are heavily rate-limited; sequential retry loops make scripts crawl. Prefer: fewer, targeted calls; batch independent probes; reuse the working node instead of rotating blindly; keep sleeps short.
- If a check will take a while anyway, tell Andee early that it is running (one short message), then report once with the verdict.
- Timed drops (lesson from Broccoli, 2026-11-10 — 500 free lots died in <57s and we missed): the baw preview→execute flow costs two Binance round-trips per attempt, and a cron that fires AT T-0 loses more seconds to worker startup. Next time: schedule the execution run a few minutes BEFORE the opening with instructions to wait warm at the gate, keep the loop tight (straight preview→execute, no re-reads between attempts), and pre-build everything. Even so, pinned-start races (expectedStart-style) with ≤500 slots are structurally hard through baw — set Yusuf's expectation honestly for those; pools in the thousands or non-pinned mints are winnable (CLAF/WNO/Cosmos/Exit Gang all landed same-day).
